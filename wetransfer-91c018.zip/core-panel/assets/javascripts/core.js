$(document).ready(function() {
  $('.slider .owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:false,
    dots:true,
    items:1
  });

  $(".announcements .announcements-filter .announcements-filter-button").click(function() {
     $(".announcements .announcements-filter .announcements-filter-list").toggleClass("active")
  });

  $(".breakcrumb-date .announcements-open").click(function() {
    $(".announcements").removeClass("announcements-slide")
  });

  $(".announcements .announcements-cancel").click(function() {
    $(".announcements").addClass("announcements-slide")
  });

  $(".side-menu .menu-item .menu-item-submenu-sub > a").click(function() {
    $(this).parent().toggleClass("active")
  });

  $(".page .content .content-container .content-box, .page .content .content-container .content-page").css({"max-height": $(".content").height() - $("#header").height() - $(".breakcrumb-date").height() - 60})

  $(".module-nav-item .module-nav-button").click(function() {
    if($(this).find("i").hasClass("icon-bar")) {
      $(this).find("i").removeClass("icon-bar")
      $(this).find("i").addClass("icon-cancel")
      $(this).parent().find(".module-sub-nav").addClass("active")
    } else {
      $(this).find("i").removeClass("icon-cancel")
      $(this).find("i").addClass("icon-bar")
      $(this).parent().find(".module-sub-nav").removeClass("active")
    }
  });

  $(".announcements-add-open").click(function() {
    $(".announcements-add").addClass("active")
  });

  $(".announcements-add-close, .announcements-add .announcements-add-bg").click(function() {
    $(".announcements-add").removeClass("active")
  });

  $(".file .file-input input").change(function() {
    var files = $(this).get(0).files;

    var output = $(this).parent().parent().find(".file-list");

    output.empty();
    for (var i = 0; i < files.length; i++) {      
      output.append("<div class='file-list-item'><p>"+files[i].name + "</p></div>");
    }
    
  });

});

$(document).ready(function() {
  $(".mobile-menu-bar").click(function() {
    if($(".page .side").hasClass("active")) {
      $(".page .side").removeClass("active")
      $(".mobile-menu-bar i").removeClass("icon-cancel")
      $(".mobile-menu-bar i").addClass("icon-bar")
      $("body").removeAttr("style")
    } else {
      $(".page .side").addClass("active")
      $(".mobile-menu-bar i").removeClass("icon-bar")
      $(".mobile-menu-bar i").addClass("icon-cancel")
      $("body").css("overflow","hidden")
    }
  });

  if ($(window).width() < 1200 ) {
    $("#header .header-right .header-profile").click(function() {
      $("#header .header-right .header-nav").toggleClass("active")
      return false
    })
  }
  if ($(window).width() < 1200 ) {
    $(".announcements").addClass("announcements-slide")
  } 
})

$(window).resize(function() {
  if ($(window).width() < 1200 ) {
    $(".announcements").addClass("announcements-slide")
  } 
})

function pictureChange(e) {
  var img = document.getElementById("picture-img");
  img.src = window.URL.createObjectURL(e.files[0])
}